import React, { Component } from 'react';
import { Text, View, Image, StyleSheet, Button, Alert } from 'react-native';

const FixedDimensionsBasics = () => {
  return (
    <View style={{ flex:1 }}>
      <View style={{ flex: 2, backgroundColor: 'white'
      }}> 
      <Text style={styles.title}>кто ты ?</Text>
      </View>
      <View style={{ flex: 3, backgroundColor: 'lightgray'
      }}>
      <Text style={styles.middle1}>"я ?" почему ?.</Text>
      
      </View>
      <View style={{ flex: 8, backgroundColor: 'gray'
      }}>
      <Text style={styles.text}>что я такое ?.</Text>
      <Button
      color='black'
      onPress={() => Alert.alert('всё')}
      title="пока"/>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: 25,
    textAlign: 'center',
    fontFamily: 'Times New Roman',
    marginTop: 40,
    margin: 10

  },
  title: {
    fontSize: 30,
    fontFamily: 'Times New Roman',
    textAlign: 'center',
    fontWeight: 'bold',
    marginTop: 60
  },
  middle1: {
    fontSize: 30,
    textAlign: 'center',
    fontFamily: 'Times New Roman',
    alignContent: 'center',
    justifyContent: 'center',
    marginTop:60
  },
  middle2: {
    fontSize: 30,
    textAlign: 'center',
    fontFamily: 'Times New Roman',
    alignContent: 'center',
    justifyContent: 'center'
  }
})

export default FixedDimensionsBasics;